local package_prefix = "Rune"
local character_name = "Royal Decree! V1"

--Everything under this comment is standard and does not need to be edited
local character_package_id = "com."..package_prefix..".char."..character_name
local mob_package_id = "com."..package_prefix..".mob."..character_name

function package_requires_scripts()
    -- Note: `requires_character` will throw if unable to find or load
--    Engine.requires_character("com.Dawn.Requested.Enemy.Catack")                         --OI LOOK HERE; DON'T FUCK WITH THESE YET!!!
--    Engine.requires_character("Entropy.HyperSpikey")                                     --OI LOOK HERE; DON'T FUCK WITH THESE YET!!!
    Engine.requires_character('com.Rune.mob.KingMett')
    Engine.requires_character('com.Rune.mob.PawnMett')
end

function package_init(package) 
    package:declare_package_id(mob_package_id)
    package:set_name(character_name)
    package:set_description("The royal family of MettVillage.")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    --can setup backgrounds, music, and field here
    local test_spawner = mob:create_spawner("com.Rune.char.PawnMett",Rank.V1)
    test_spawner:spawn_at(5, 1)
    local test_spawner = mob:create_spawner("com.Rune.char.PawnMett",Rank.V1)
    test_spawner:spawn_at(4, 3)
    local test_spawner = mob:create_spawner("com.Rune.char.KingMett",Rank.V1)
    test_spawner:spawn_at(6, 2)
    mob:set_background(_modpath.."background.png","background.png",0.4,0.4)
    mob:stream_music(_modpath.."music.ogg",0,2310)
end