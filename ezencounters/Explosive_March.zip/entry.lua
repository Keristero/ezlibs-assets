local package_prefix = "Entropy"
local character_name = "Explosive March"

--Everything under this comment is standard and does not need to be edited
local character_package_id = "com."..package_prefix..".char."..character_name
local mob_package_id = "com."..package_prefix..".mob."..character_name

function package_requires_scripts()
    -- Note: `requires_character` will throw if unable to find or load
    Engine.requires_character("com.Dawn.Requested.Enemy.Catack")
    Engine.requires_character("Entropy.HyperSpikey")
end

function package_init(package) 
    package:declare_package_id(mob_package_id)
    package:set_name(character_name)
    package:set_description("Kill that Catack quick, or it's going to make your life very hard.")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    --can setup backgrounds, music, and field here
    local test_spawner = mob:create_spawner("com.Entropy.char.HyperSpikey",Rank.V1)
    test_spawner:spawn_at(6, 1)
    local test_spawner = mob:create_spawner("com.Dawn.Requested.Enemy.Catack",Rank.SP)
    test_spawner:spawn_at(5, 2)
    mob:set_background(_modpath.."background.png","background.png",0,0)
    mob:stream_music(_modpath.."music.ogg",0,2310)
end